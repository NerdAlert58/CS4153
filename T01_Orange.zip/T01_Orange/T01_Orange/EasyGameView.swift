//
//  EasyGameView.swift
//  T01_Orange
//
//  Created by Tyler Weppler on 9/18/16.
//  Copyright © 2016 Scott Bushyhead. All rights reserved.



import UIKit

class EasyGameView: UIView {


    override func draw(_ rect: CGRect) {

    }
}
