//
//  ViewController.swift
//  T01_Orange
//
//  Created by Scott Bushyhead on 9/11/16.
//  Copyright © 2016 Scott Bushyhead. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblSplash: UILabel!
    @IBOutlet weak var btnStart: UIButton!
    
    @IBAction func btnClicked(_ sender: AnyObject) {
        btnStart.imageView?.image = UIImage(named: "Start.png")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

